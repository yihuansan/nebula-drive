import {
  closeDb,
  getDb
} from "./chunk-AXILL5Y5.js";
import "./chunk-GF2APMXG.js";
export {
  closeDb,
  getDb
};
